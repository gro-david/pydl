mv ./pydl /usr/bin/pydl
