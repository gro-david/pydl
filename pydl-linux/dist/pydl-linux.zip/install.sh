mkdir -p /usr/bin/pydl
mv .pydl /usr/bin/pydl/pydl
